
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'alshoja',
  applicationName: 'aws-node',
  appUid: 'WvNgzn0FMyXnK2xxbv',
  orgUid: 'b8db23c1-a98c-49ac-b855-f7b453d93277',
  deploymentUid: '59e8749b-aa1c-4669-9fed-9aa9b640e22c',
  serviceName: 'serverless-posts',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-posts-dev-main', timeout: 6 };

try {
  const userHandler = require('./dist/src/serverless.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}