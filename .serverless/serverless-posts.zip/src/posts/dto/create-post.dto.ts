export class CreatePostDto {
  id: number;
  userId: number;
  title?: string;
  body?: string;
}
